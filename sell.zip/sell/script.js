// script.js
// Initialize Firebase
const firebaseConfig = {
  // تكوين Firebase هنا
};

firebase.initializeApp(firebaseConfig);
const database = firebase.database();

// حفظ البيانات في قاعدة البيانات
document.getElementById("data-form").addEventListener("submit", function(event) {
  event.preventDefault();
  const branchName = document.getElementById("branch-name").value;
  const date = document.getElementById("date").value;
  const sales = document.getElementById("sales").value;
  const returns = document.getElementById("returns").value;
  const netSales = document.getElementById("net-sales").value;
  const budget = document.getElementById("budget").value;
  const expenses = document.getElementById("expenses").value;
  const cash = document.getElementById("cash").value;

  database.ref('data').push({
    branch_name: branchName,
    date: date,
    sales: sales,
    returns: returns,
    net_sales: netSales,
    budget: budget,
    expenses: expenses,
    cash: cash
  });

  document.getElementById("data-form").reset();
});

// عرض البيانات من Firebase
database.ref('data').on('value', function(snapshot) {
  const dataBody = document.getElementById("data-body");
  dataBody.innerHTML = "";
  snapshot.forEach(function(childSnapshot) {
    const data = childSnapshot.val();
    const row = `
      <tr>
        <td>${data.sales}</td>
        <td>${data.returns}</td>
        <td>${data.net_sales}</td>
        <td>${data.budget}</td>
        <td>${data.expenses}</td>
        <td>${data.cash}</td>
      </tr>`;
    dataBody.insertAdjacentHTML('beforeend', row);
  });
});

// تصدير البيانات إلى Excel
document.getElementById("export-btn").addEventListener("click", function() {
  const table = document.getElementById("data-table");
  const htmlTableToExcel = new HtmlTableToExcel();
  htmlTableToExcel.createFile(table, "بيانات_الشركة");
});

// فحص كلمة المرور
document.getElementById("query").addEventListener("click", function() {
  const password = document.getElementById("password").value;
  if (password === "123") {
    alert("تمت المصادقة بنجاح!");
    // عرض البيانات بعد التصديق
    document.getElementById("data-display").style.display = "block";
  } else {
    alert("كلمة المرور غير صحيحة!");
  }
});
